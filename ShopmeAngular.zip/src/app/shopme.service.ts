import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShopmeService {
  
  public isUserLogged: boolean;

  cartitems: any = [];
  private itemInCart = new BehaviorSubject([]);
  itemsInCart$ = this.itemInCart.asObservable();
  
  constructor(public httpClient: HttpClient) {
    this.isUserLogged = false;
  }

  public setUserLoggedIn(): void {
    this.isUserLogged = true;
  }

  public getUserLoggedIn(): any {
    return this.isUserLogged;
  }

  public setUserLoggedOut(): void {
    this.isUserLogged = false;
  }


  getCustomer(userName: any, password: any): any {
    return this.httpClient.get('getCustomer/' + userName + '/' + password);
  }

  register(customer : any): any {
    return this.httpClient.post('/registerCustomer' , customer);
  }

  updateCustomer(customer : any): any {
    return this.httpClient.post('updateCustomer', customer);
  }

  setItemInCart(item: any) {
    this.setCountForItemsInCart(this.cartitems, item);
    this.itemInCart.next(this.cartitems);
  }

  setCountForItemsInCart(array: any, item: any) { debugger
    if(array.length === 0) {
      item.count = 1;
      array.push(item);
      return;
    }
    const items = array.map((data: any) => data.productId);
    if(items.includes(item.productId)) { 
      array[items.indexOf(item.productId)].count++;
    } else {
      item.count = 1;
      array.push(item);
    }
  }

  deletecartdata(){
      this.cartitems = [];
      this.itemInCart.next([]);
  }


  postFile(ImageForm: any, fileToUpload: File) {
    // goes to rest api employee controller
    const endpoint = 'uploadImage';
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('productName', ImageForm.productName);
    formData.append('availability', ImageForm.availability);
    formData.append('price', ImageForm.price);
    return this.httpClient.post(endpoint, formData);
  }

  getAllProducts() {
    return this.httpClient.get('showAllProducts');
  }
}
