# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [6.2.0](https://github.com/Enngage/ngx-paypal/compare/v0.0.1...v6.2.0) (2020-09-02)


### Features

* updates to Angular 10 ([83f6b7e](https://github.com/Enngage/ngx-paypal/commit/83f6b7e1b39f1702663923e91e08d3f775ac0541))
